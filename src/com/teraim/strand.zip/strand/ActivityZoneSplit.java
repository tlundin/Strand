package com.teraim.strand;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.teraim.strand.dataobjekt.InputAlertBuilder;
import com.teraim.strand.dataobjekt.InputAlertBuilder.AlertBuildHelper;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.text.SpannableString;
import android.text.style.UnderlineSpan;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;

/**
 * 
 * @author Terje
 *
 * Class that allows dividing beach into zones.
 */
public class ActivityZoneSplit extends Activity {



	//HYDRO
	private static final int ID_StrandTyp = 0;
	private static final int ID_KustTyp = 1;
	private static final int ID_V�gExponering = 2;
	private static final int ID_Vattendjup = 3;

	//EXTRA
	private static final int ID_TradForekomst = 10;
	private static final int ID_SlutlenOvan = 11;
	private static final int ID_LutningExtra = 12;

	//GEO	
	private static final int ID_SlutlenGeo= 20;
	private static final int ID_LutningGeo= 21;

	//SUPRA
	private static final int ID_SlutlenSupra= 30;
	private static final int ID_LutningSupra= 31;
	






	protected static final String TypeDigit = "DIGIT";
	TextView extraT,supraT,geoT,hydroT;
	LinearLayout bg;

	//convenience..
	Provyta py = Strand.getCurrentProvyta(this);



	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_zone_split);

		extraT = (TextView)this.findViewById(R.id.extraT);
		supraT = (TextView)this.findViewById(R.id.supraT);
		geoT = (TextView)this.findViewById(R.id.geoT);
		hydroT = (TextView)this.findViewById(R.id.hydroT);


		//Main view that will be filled with variables depending on zone.
		bg = (LinearLayout)this.findViewById(R.id.contentPane);




		extraT.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {


				bg.removeAllViews();

				//SlutL�ngd Extralitoral
				addNormalInput(bg,"Slutl�ngd Extra","Avst�nd fr�n medelvattenlinjen till d�r hela transekten slutar",py.getSlutlenovan(),ID_SlutlenOvan,InputType.TYPE_CLASS_NUMBER);

				
				//Tr�df�rekomst
				addBooleanInput(bg,"Tr�df�rekomst","Ifall det inte �r fastland, finns det ett skogsbets�nd > 0.25 ha (1/0)?",py.getTr�df�rekomst(),ID_TradForekomst);

				
				//Lutning

				addNormalInput(bg,"Lutning Supra","M�tt lutning i Extralittoralen (grader)",py.getLutningextra(),ID_LutningExtra,InputType.TYPE_CLASS_NUMBER);

				
			}});


		supraT.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				bg.removeAllViews();

				//SlutL�ngd Extralitoral
				addNormalInput(bg,"Slutl�ngd Supra","Avst�nd fr�n medelvattenlinjen till d�r Supralittoralen slutar",py.getSlutlensupra(),ID_SlutlenSupra,InputType.TYPE_CLASS_NUMBER);
						
				//Lutning 
				
				addNormalInput(bg,"Lutning Supra","M�tt lutning i supralittralen (grader)",py.getLutningsupra(),ID_LutningSupra,InputType.TYPE_CLASS_NUMBER);

			
			
			}});


		hydroT.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				bg.removeAllViews();

				//Strandtyp
				List<String> values = new ArrayList<String>(Arrays.asList("1","2","3","4","5"));
				List<String> entries = new ArrayList<String>(Arrays.asList("Klippa/H�ll","Block/Grus","Sand","Strand�ng/V�tmark","Konstruerad"));
				addSpinnerInput(bg,"Strandtyp","Klassning 1-5",py.getStrandtyp(),ID_StrandTyp,entries,values);

				//Kusttyp
				values = new ArrayList<String>(Arrays.asList("fastland","�ar","sk�r","grund"));
				entries = values;
				addSpinnerInput(bg,"Kusttyp","V�lj bland nedanst�ende",py.getKusttyp(),ID_KustTyp,entries,values);

				//V�gexponering
				addNormalInput(bg,"V�gexponering","Bed�m exponeringklass. J�mf�r med utdata och �ndra om det (uppenbart) ej st�mmer",py.getExponering(),ID_V�gExponering,InputType.TYPE_CLASS_NUMBER);

				//Vattendjup
				addNormalInput(bg,"Vattendjup","M�tt vattendjup 3 m utanf�r medelvattenlinjen",py.getExponering(),ID_Vattendjup,InputType.TYPE_CLASS_NUMBER);
				
			}});

		
		geoT.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				bg.removeAllViews();

				
				//SlutL�ngd 
				addNormalInput(bg,"Slutl�ngd Geo","Avst�nd l�ngs transekten fr�n medelvattenlinjen till d�r geolittoralen slutar (dm)",py.getSlutlengeo(),ID_SlutlenGeo,InputType.TYPE_CLASS_NUMBER);
			
				//Lutning 
				
				addNormalInput(bg,"Lutning Geo","M�tt lutning i geolittralen (grader)",py.getLutninggeo(),ID_LutningGeo,InputType.TYPE_CLASS_NUMBER);
			
			
			}});
	}




	private View createClickableField(ViewGroup bg,String headerT,String defValue) {

		View view = LayoutInflater.from(getBaseContext()).inflate(R.layout.editfield,null);
		bg.addView(view);
		TextView header = (TextView)view.findViewById(R.id.editfieldtext);
		SpannableString content = new SpannableString(headerT);
		content.setSpan(new UnderlineSpan(), 0, content.length(), 0);
		header.setText(content);
		final TextView et = (TextView)view.findViewById(R.id.editfieldinput);
		et.setText(defValue);
		view.setClickable(true);
		return view;	
	}



	private View addBooleanInput(ViewGroup bg,final String headerT,final String bodyT,final String currValue,final int id) {
		final View v = createClickableField(bg,headerT,currValue);

		final AlertBuildHelper abh = new AlertBuildHelper(getBaseContext()) {
			@Override
			public View createView() {
				// Set an EditText view to get user input 
				View view = LayoutInflater.from(c).inflate(R.layout.ja_nej_radiogroup,null);
				RadioButton ja = (RadioButton)view.findViewById(R.id.ja);
				RadioButton nej = (RadioButton)view.findViewById(R.id.nej);
				if(currValue!=null) {
					if(currValue.equals("1"))
						ja.setEnabled(true);
					else
						nej.setEnabled(true);
					ja.setChecked(true);
				}
				return view;
			}
			@Override
			public void setResult(int id, View inputView,View outputView) {
				setStringValue(id,((RadioButton)inputView.findViewById(R.id.ja)).isChecked()?"1":"0",v);
			}};		

			v.setOnClickListener(InputAlertBuilder.createAlert(id,headerT,bodyT,abh,v));
			return v;		

	}

	private View addSpinnerInput(ViewGroup bg,final String headerT,final String bodyT,final String currValue,final int id, final List<String>entries, final List<String>values) {

		final View v = createClickableField(bg,headerT,currValue);

		final AlertBuildHelper abh = new AlertBuildHelper(getBaseContext()) {
			@Override
			public View createView() {
				// Set an EditText view to get user input 
				final Spinner spinner = new Spinner(c);
				ArrayAdapter<String> adapter = new ArrayAdapter<String>(c, android.R.layout.simple_spinner_dropdown_item, entries);		
				spinner.setAdapter(adapter);

				return spinner;
			}
			@Override
			public void setResult(int id, View inputView,View outputView) {
				Log.d("Strand","Value for spinner: "+values.get(((Spinner)inputView).getSelectedItemPosition()));
				setStringValue(id,values.get(((Spinner)inputView).getSelectedItemPosition()),outputView);
			}};


			v.setOnClickListener(InputAlertBuilder.createAlert(id,headerT,bodyT,abh,v));
			return v;		
	}

	private View addNormalInput(ViewGroup bg,final String headerT,final String bodyT,final String currValue, final int id, final int inputType) {
		final View v = createClickableField(bg, headerT,currValue);
		final TextView et = (TextView)v.findViewById(R.id.editfieldinput);
		final InputAlertBuilder.AlertBuildHelper abh = new AlertBuildHelper(this.getBaseContext()) {
			@Override
			public View createView() {
				// Set an EditText view to get user input 
				final EditText input = new EditText(c);

				input.setText(et.getText());
				//input.setInputType(inputType);

				return input;
			}

			@Override
			public void setResult(int id,View inputView,View outputView) {
				setStringValue(id,((EditText)inputView).getText().toString(),outputView);
			}};

			v.setOnClickListener(InputAlertBuilder.createAlert(id,headerT,bodyT,abh,v));

			return v;		

	}


	private void setStringValue(int id, String value, View v) { 
			switch(id) {
			case ID_SlutlenOvan:
				py.setSlutlenovan(value);
				break;

			case ID_SlutlenGeo:
				py.setSlutlengeo(value);
				break;
			case ID_StrandTyp:
				py.setStrandtyp(value);
				break;

			case ID_KustTyp:
				py.setKusttyp(value);
				break;

			case ID_TradForekomst:
				py.setTr�df�rekomst(value);
				break;
			
			case ID_V�gExponering:
				py.setExponering(value);
				break;
				
			case ID_SlutlenSupra:
				py.setSlutlensupra(value);
				break;
			
			case ID_LutningGeo:
				py.setLutninggeo(value);
				break;
			case ID_LutningSupra:
				py.setLutningsupra(value);
				break;
			case ID_LutningExtra:
				py.setLutningextra(value);
				break;
			case ID_Vattendjup:
				py.setVattendjup(value);
				break;
			}
			
	}


	
	@Override
	public void onSaveInstanceState(Bundle savedInstanceState) {
	   Log.d("Strand","onsaveinstance called");
		//Spara v�rden
		Persistent.onSave(py);
	    super.onSaveInstanceState(savedInstanceState);
	}
	
	public void onVidare(View v) {
		Log.d("Strand","onvidare called");
		Intent i = new Intent(this, ActivityZoneless.class);
		startActivity(i);
	}

}
