package com.teraim.strand.dataobjekt;

import android.content.Context;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import com.teraim.strand.R;

public class TableArter extends TableBase {
	
	protected final static int[] columnIds = new int[] {R.id.namn, R.id.supra, R.id.geo,R.id.extra};
	protected final static String[] columnName = new String[] {"NAMN","SUPRA","GEO","EXTRA"};

	
	public TableArter(Context c, Table data) {
		super(c,data);
		init();
		
	}

	@Override
	public void addRow(String name) {
		TableRow row = super.createRow(R.layout.row_arter_table);
		assert(row!=null);
		((TextView)row.findViewById(R.id.namn)).setText(name);;
		addView(row);
	}

	@Override
	public void init() {
		createHeader(R.layout.row_arter_table,columnIds,columnName);
		
	}
	

	
	
	
}
