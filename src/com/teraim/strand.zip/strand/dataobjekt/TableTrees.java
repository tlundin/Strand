package com.teraim.strand.dataobjekt;

import java.util.Arrays;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.TableRow;
import android.widget.TextView;

import com.teraim.strand.R;
import com.teraim.strand.dataobjekt.InputAlertBuilder.AlertBuildHelper;

public class TableTrees extends TableBase {

	protected TextView avstT,artT,diameterT,antalT;
	protected EditText avstE,diameterE,antalE;
	protected int rowC = 0;
	protected final static int[] columnIds = new int[] {R.id.avst, R.id.art, R.id.diameter,R.id.antal};
	protected final static String[] columnName = new String[] {"Avst�nd","Art","Diameter","Antal"};


	public TableTrees(Context c, Table data) {
		super(c,data);
		init();
	}


	//Creates a row. Will also (side effect) create a new row in the Data Table.
	@Override
	public void addRow(String name) {
		String[] entries = new String[4];
		entries[0]="";
		entries[1]=name;
		entries[2]="";
		entries[3]="";
		String myID = myData.getNextId();
		addRow(myID,entries);
		myData.saveRow(myID, "",name,"","");
	}

	
	
	private void addRow(Entry<String, String[]> row) {
		addRow(row.getKey(),row.getValue());
	}

	
	//creates a row. Will return the row number of the created row.

	private void addRow(final String myID, final String[] entries) {


		final TableRow row = super.createRow(R.layout.row_trees_table);
		assert(row!=null);


		avstT = (TextView)row.findViewById(R.id.avst);
		artT = (TextView)row.findViewById(R.id.art);
		antalT = (TextView)row.findViewById(R.id.antal);
		diameterT = (TextView)row.findViewById(R.id.diameter);

		assert(entries.length==4);
		//Load
		avstT.setText(entries[0]);
		artT.setText(entries[1]);
		antalT.setText(entries[2]);
		diameterT.setText(entries[3]);
		
		Log.d("Strand", "S�tter avstT onclick");


		row.setTag(myID);		
		row.setOnClickListener(

				InputAlertBuilder.createAlert(-1, "Tr�d","Inmatning f�r "+entries[1]+". V�nligen mata in antingen antal eller diameter. Inte b�de och!", 
						new AlertBuildHelper(TableTrees.this.getContext()){

					@Override
					public View createView() {
						View inputView = LayoutInflater.from(c).inflate(R.layout.tree_table_popup,null);
						avstE = (EditText)inputView.findViewById(R.id.avst);
						antalE = (EditText)inputView.findViewById(R.id.antal);
						diameterE = (EditText)inputView.findViewById(R.id.diameter);							
						return inputView;
					}

					@Override
					public void setResult(int resultId, View inputView,
							View outputView) {
						TextView avstT,antalT,diameterT;
						avstT = (TextView)outputView.findViewById(R.id.avst);
						antalT = (TextView)outputView.findViewById(R.id.antal);
						diameterT = (TextView)outputView.findViewById(R.id.diameter);

						avstT.setText(avstE.getText());
						antalT.setText(antalE.getText());
						diameterT.setText(diameterE.getText());
						String avst = "",ant="",diam="",art="";
						if(avstE.getText()!=null)
							avst = avstE.getText().toString();
						if(antalE.getText()!=null)
							ant = antalE.getText().toString();
						if(diameterE.getText()!=null)
							diam = diameterE.getText().toString();
						art = entries[1];
						myData.saveRow(myID,avst,art,ant,diam);

					}}, row)
				);		
		row.setOnLongClickListener(new OnLongClickListener() {

			@Override
			public boolean onLongClick(View arg0) {
				removeRow(row);
				return true;
			}});


		addView(row);
		
	}




	protected void removeRow(TableRow row) {
		myData.deleteRow((String)row.getTag());
		removeView(row);		
	}


	@Override
	public void init() {
		createHeader(R.layout.row_trees_table,columnIds,columnName);
		Set<Entry<String, String[]>> rows =  myData.getTable();
		if (rows!=null)
			for(Entry<String, String[]> row:rows) {
				addRow(row);
			}

	}


	


}
