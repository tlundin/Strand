package com.teraim.strand.dataobjekt;
import android.content.Context;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

public abstract class TableBase extends TableLayout {
	
	protected Table myData;
	
		
	public TableBase(Context c,Table data) {
		super(c);
		myData = data;
	}
	
	protected void createHeader(int rowId, int[] columnIds, String[] columnName) {
		int i = 0;
		TableRow header  = createRow(rowId);
		addView(header);
		TextView tv;
		for(int id:columnIds) {
			tv = (TextView)header.findViewById(id);
			tv.setText(columnName[i++]);	
			tv.setTypeface(null,Typeface.BOLD);
		}
		
	}
	
	
	public TableRow createRow(int resId) {	
		return (TableRow)LayoutInflater.from(getContext()).inflate(resId,null);
	}

	public abstract void addRow(String name);
	
	public abstract void init();
}
